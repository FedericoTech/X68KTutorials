#include <doslib.h>

int main(void)
{
    _dos_c_print("Hello world !\r\n");

    _dos_exit();
}
